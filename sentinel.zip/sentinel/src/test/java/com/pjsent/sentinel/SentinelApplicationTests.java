package com.pjsent.sentinel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentinelApplicationTests {

	@Test
	void contextLoads() {
	}

}
